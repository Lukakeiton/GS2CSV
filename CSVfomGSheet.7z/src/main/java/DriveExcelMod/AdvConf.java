package DriveExcelMod;

import java.awt.BorderLayout;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
//import javax.swing.event.ChangeEvent;
//import javax.swing.event.ChangeListener;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JButton;
//import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.SwingConstants;
import javax.swing.JFileChooser;

import java.awt.Color;
//import java.awt.Window.Type;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.awt.event.ActionEvent;

public class AdvConf extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3186380878635724874L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	private String JSON_PATH=null;
	
	private String spreadsheetId;
	private int sheetId;
	static JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdvConf frame = new AdvConf();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdvConf() {
		setType(Type.UTILITY);
		setTitle("CSVfromGSheet");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane, BorderLayout.CENTER);
		
		String title = "Luis Martinez Jaraba";
		Border border = BorderFactory.createTitledBorder(title);
		contentPane.setBorder(border);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Principal", null, panel_1, null);
		tabbedPane.setEnabledAt(0, true);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{0, 0, 0, 0, 0};
		gbl_panel_1.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel_1.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		File credentials=new File("src/main/resources/credentials.json");
		if(!credentials.exists()) {
			JLabel lblNewLabel_4 = new JLabel("Seleccionar JSON");
			GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
			gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_4.gridx = 1;
			gbc_lblNewLabel_4.gridy = 0;
			panel_1.add(lblNewLabel_4, gbc_lblNewLabel_4);
		
			JButton btnNewButton = new JButton("Buscar archivo...");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					JFileChooser fileChooser = new JFileChooser();
					fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
					int result = fileChooser.showOpenDialog(contentPane);
					if (result == JFileChooser.APPROVE_OPTION) {
					    // user selects a file
						File selectedFile = fileChooser.getSelectedFile();
						JSON_PATH=selectedFile.getAbsolutePath();
						try {
				            FileInputStream in = new FileInputStream(JSON_PATH);
				            FileOutputStream out = new FileOutputStream(new File("src/main/resources/credentials.json"));
				            int c;
				            while( (c = in.read() ) != -1)
				                out.write(c);

				            in.close();
				            out.close();
				        } catch(IOException e) {
				            msgbox("No se ha podido copiar correctamente");
				        }
						msgbox("Archivo seleccionado correctamente");
					}
				}
			});
		
			GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
			gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
			gbc_btnNewButton.gridx = 1;
			gbc_btnNewButton.gridy = 1;
			panel_1.add(btnNewButton, gbc_btnNewButton);
		
		}
		else {
			JSON_PATH=credentials.getAbsolutePath();
		}
		
		File data = new File("src/main/resources/data.txt");
		
		if(!data.exists()) {
			JLabel lblNewLabel = new JLabel("ID Documento");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 1;
			gbc_lblNewLabel.gridy = 2;
			panel_1.add(lblNewLabel, gbc_lblNewLabel);
			
			textField = new JTextField();
			GridBagConstraints gbc_textField = new GridBagConstraints();
			gbc_textField.insets = new Insets(0, 0, 5, 5);
			gbc_textField.fill = GridBagConstraints.HORIZONTAL;
			gbc_textField.gridx = 1;
			gbc_textField.gridy = 3;
			panel_1.add(textField, gbc_textField);
			textField.setColumns(10);
			
			JLabel lblNewLabel_1 = new JLabel("ID Hoja");
			GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
			gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_1.gridx = 1;
			gbc_lblNewLabel_1.gridy = 4;
			panel_1.add(lblNewLabel_1, gbc_lblNewLabel_1);
			
			textField_1 = new JTextField();
			GridBagConstraints gbc_textField_1 = new GridBagConstraints();
			gbc_textField_1.insets = new Insets(0, 0, 5, 5);
			gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
			gbc_textField_1.gridx = 1;
			gbc_textField_1.gridy = 5;
			panel_1.add(textField_1, gbc_textField_1);
			textField_1.setColumns(10);
		}
		
		JButton btnNewButton_2 = new JButton("Generar CSV");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(JSON_PATH!=null) {
					if(!data.exists()) {
							try {
								FileWriter out1 = new FileWriter(new File("src/main/resources/data.txt"));
								spreadsheetId=textField.getText();
								sheetId=Integer.parseInt(textField_1.getText());
								out1.write(spreadsheetId);
								out1.write("\n");
								out1.write(sheetId+"");
								out1.write("\n");
								out1.close();
								String path=DriveExcelMod.mainn(JSON_PATH,spreadsheetId, sheetId);
								msgbox("CSV creado correctamente en "+path);
							} catch (IOException | GeneralSecurityException x) {
								x.printStackTrace();
							} catch(NumberFormatException e) {
								msgbox("Introduzca el ID de la hoja correctamente");
								textField_1.setText("");
							}
					}
					else {
						try {
							String[] ids=new String[2];
							String texto=leerString("src/main/resources/data.txt");
							ids=texto.split("\n");
							spreadsheetId=ids[0];
							sheetId=Integer.parseInt(ids[1]);
							
							String path=DriveExcelMod.mainn(JSON_PATH,spreadsheetId, sheetId);
							msgbox("CSV creado correctamente en "+path);
						} catch(IOException | GeneralSecurityException e) {
				            msgbox("No se ha podido cargar correctamente");
				        }
					}
				}
				else {
					msgbox("Seleccione el archivo 'credentials.json'");
				}
			}
		});
		
		GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
		gbc_btnNewButton_2.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton_2.gridx = 1;
		gbc_btnNewButton_2.gridy = 6;
		panel_1.add(btnNewButton_2, gbc_btnNewButton_2);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		tabbedPane.addTab("Identificador", null, panel, null);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JLabel lblNewLabel_3 = new JLabel("Ubicacion del identificador");
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.gridwidth = 2;
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_3.gridx = 2;
		gbc_lblNewLabel_3.gridy = 1;
		panel.add(lblNewLabel_3, gbc_lblNewLabel_3);
		
		JLabel lblNewLabel_6 = new JLabel("Hoja");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
		gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6.gridx = 1;
		gbc_lblNewLabel_6.gridy = 3;
		panel.add(lblNewLabel_6, gbc_lblNewLabel_6);
		
		textField_2 = new JTextField();
		GridBagConstraints gbc_textField_2 = new GridBagConstraints();
		gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_2.insets = new Insets(0, 0, 5, 5);
		gbc_textField_2.gridx = 2;
		gbc_textField_2.gridy = 3;
		panel.add(textField_2, gbc_textField_2);
		textField_2.setColumns(10);
		textField_2.setText("1");
		
		JLabel lblNewLabel_7 = new JLabel("Nombre de la hoja");
		GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
		gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_7.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_7.gridx = 1;
		gbc_lblNewLabel_7.gridy = 5;
		panel.add(lblNewLabel_7, gbc_lblNewLabel_7);
		
		textField_5 = new JTextField();
		GridBagConstraints gbc_textField_5 = new GridBagConstraints();
		gbc_textField_5.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_5.insets = new Insets(0, 0, 5, 5);
		gbc_textField_5.gridx = 2;
		gbc_textField_5.gridy = 5;
		panel.add(textField_5, gbc_textField_5);
		textField_5.setColumns(10);
		textField_5.setText("Respuestas de formulario 1");
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		tabbedPane.addTab("Avanzado", null, panel_2, null);
		GridBagLayout gbl_panel_2 = new GridBagLayout();
		gbl_panel_2.columnWidths = new int[]{0, 0, 0};
		gbl_panel_2.rowHeights = new int[]{0, 0, 0};
		gbl_panel_2.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_panel_2.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		panel_2.setLayout(gbl_panel_2);
		
		JButton btnNewButton_1 = new JButton("Borrar credenciales");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.gridx = 1;
		gbc_btnNewButton_1.gridy = 1;
		panel_2.add(btnNewButton_1, gbc_btnNewButton_1);
	}
	
	private void msgbox(String s){
		   JOptionPane.showMessageDialog(null, s);
	}
	
	public static String leerString(String ruta) throws IOException {
		String texto = "";
		try {
			FileReader fileReader = new FileReader(ruta);
			int character = 0;
			do {
				character = fileReader.read();
				if(character != -1)
					texto = texto + (char)character;
			} while (character != -1);
			fileReader.close();
		} catch (FileNotFoundException e) {}
		return texto;
	}
	
//	public void stateChanged(ChangeEvent e) {
//        if (rdbtnNewRadioButton.isSelected()) {
//        	rdbtnNewRadioButton_1.setSelected(false);
//        }
//        if (rdbtnNewRadioButton_1.isSelected()) {
//        	rdbtnNewRadioButton.setSelected(false);
//        }      
//    }

}
