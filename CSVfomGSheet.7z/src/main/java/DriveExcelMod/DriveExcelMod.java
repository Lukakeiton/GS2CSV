package DriveExcelMod;

import com.google.api.client.auth.oauth2.Credential;



import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
//import com.google.api.services.drive.Drive;
//import com.google.api.services.drive.model.File;
//import com.google.api.services.drive.model.FileList;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
//import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetRequest;
//import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetResponse;
import com.google.api.services.sheets.v4.model.CellData;
import com.google.api.services.sheets.v4.model.CellFormat;
//import com.google.api.services.sheets.v4.model.CellFormat.*;
import com.google.api.services.sheets.v4.model.Color;
//import com.google.api.services.sheets.v4.model.CopyPasteRequest;
//import com.google.api.services.sheets.v4.model.GridData;
import com.google.api.services.sheets.v4.model.GridRange;
import com.google.api.services.sheets.v4.model.RepeatCellRequest;
import com.google.api.services.sheets.v4.model.Request;
//import com.google.api.services.sheets.v4.model.RowData;
//import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.api.services.sheets.v4.model.Spreadsheet;
//import com.google.api.services.sheets.v4.model.SpreadsheetProperties;
import com.google.api.services.sheets.v4.model.TextFormat;
//import com.google.api.services.drive.model.File;
//import com.google.api.services.sheets.v4.model.TextFormatRun;
//import com.google.api.services.sheets.v4.model.UpdateCellsRequest;
//import com.google.api.services.sheets.v4.model.UpdateSheetPropertiesRequest;
//import com.google.api.services.sheets.v4.model.UpdateSpreadsheetPropertiesRequest;

import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
//import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DriveExcelMod {
	private static final String APPLICATION_NAME = "creaCSV";
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
    private static final String TOKENS_DIRECTORY_PATH = "tokens";

    /**
     * Global instance of the scopes required by this quickstart.
     * If modifying these scopes, delete your previously saved tokens/ folder.
     */
    private static final List<String> SCOPES = Collections.singletonList(SheetsScopes.SPREADSHEETS);
    private static String CREDENTIALS_FILE_PATH;
    /**
     * Creates an authorized Credential object.
     * @param HTTP_TRANSPORT The network HTTP Transport.
     * @return An authorized Credential object.
     * @throws IOException If the credentials.json file cannot be found.
     */
    private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
        // Load client secrets.
        InputStream in = new FileInputStream(CREDENTIALS_FILE_PATH);
        		
        		//DriveExcelMod.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
//        if (in == null) {
//            throw new FileNotFoundException("Archivo no encontrado: " + CREDENTIALS_FILE_PATH);
//        }
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

        // Build flow and trigger user authorization request.
        GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
                .setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
                .setAccessType("offline")
                .build();
        LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
        return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
    }

    /**
     * Prints the names and majors of students in a sample spreadsheet:
     * https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
     */
    public static String mainn(String JSON_PATH, String spreadsheetId, int sheetId) throws IOException, GeneralSecurityException {
    	CREDENTIALS_FILE_PATH=JSON_PATH;
    	String range = AdvConf.textField_5.getText();
        Sheets service=getService();
        service.spreadsheets().values()
                .get(spreadsheetId, range)
                .execute();
        Sheets.Spreadsheets.Get get = service.spreadsheets().get(spreadsheetId).setIncludeGridData(true);
        Spreadsheet sheet = get.execute();
        int numRows=getNumRows(sheet);
        int numColor=getNumLastColorTextCell(sheet);
        String path="";
        if(numRows!=numColor) {
        	service=getService();
            service.spreadsheets().values()
                    .get(spreadsheetId, range)
                    .execute();
            get = service.spreadsheets().get(spreadsheetId).setIncludeGridData(true);
            sheet = get.execute();
        	path=CSV.create(getCSV(sheet,numColor,numRows),"import2Moodle");
          updateLastCell(sheet,0,0,numRows,numColor);
          sendChanges(sheet,spreadsheetId,sheetId,numColor,numRows-1);
        }
        else {
        	path=null;
        }
        return path;
    }
    
    private static Sheets getService() throws GeneralSecurityException, IOException {
    	// Build a new authorized API client service.
        final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
        return new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
                .setApplicationName(APPLICATION_NAME)
                .build();
    }
    
    private static int getNumLastColorTextCell(Spreadsheet sheet) {
    	int numRows=sheet.getSheets().get(0).getData().get(0).getRowData().size();
    	int n=0;
    	for(int i=0;i<numRows;i++) {
        	if(sheet.getSheets().get(0).getData().get(0).getRowData().get(i).getValues().get(0).getEffectiveFormat().getTextFormat().getForegroundColor().toString().equals("{}")==false) {
        		n=i;
        	}
        }
    	return n;
    }
    
    private static int getNumRows(Spreadsheet sheet) {
    	return sheet.getSheets().get(0).getData().get(0).getRowData().size();
    }
    
    private static List<String[]> getCSV(Spreadsheet sheet,int numColor,int numRows){
    	List<String[]> listaAux=new ArrayList<>();
    	for(int i=numColor+1;i<numRows;i++) {
    		String[] aux=new String[4];
    		aux[0]=sheet.getSheets().get(0).getData().get(0).getRowData().get(i).getValues().get(1).getFormattedValue().toString();
    		aux[1]=sheet.getSheets().get(0).getData().get(0).getRowData().get(i).getValues().get(2).getFormattedValue().toString();
    		aux[2]=sheet.getSheets().get(0).getData().get(0).getRowData().get(i).getValues().get(3).getFormattedValue().toString();
    		aux[3]=sheet.getSheets().get(0).getData().get(0).getRowData().get(i).getValues().get(3).getFormattedValue().toString();
    		listaAux.add(aux);
    	}
    	return listaAux;
    }
    
    private static void updateLastCell(Spreadsheet sheet,int numSheet,int numCol,int numRows,int numColor) {
//    	System.out.println(sheet.getSheets().get(0).getData().get(0).getRowData().get(numCol).getValues().get(0).getEffectiveFormat().getTextFormat().getForegroundColor().toString());
    	if(numColor==0) {
    		//Falta determinar el color rojo en hexadecimal para setearlo por defecto.
    		sheet.getSheets().get(numSheet).getData().get(numCol).getRowData().get(numRows-1).getValues().get(0).getEffectiveFormat().getTextFormat().setForegroundColor(new Color().setRed(1f).setGreen(null).setBlue(null).setAlpha(null));
    	}
    	else {
    		sheet.getSheets().get(numSheet).getData().get(numCol).getRowData().get(numRows-1).getValues().get(0).getEffectiveFormat().getTextFormat().setForegroundColor(sheet.getSheets().get(0).getData().get(0).getRowData().get(numCol).getValues().get(0).getEffectiveFormat().getTextFormat().getForegroundColor());
    		
    	}
    }
    
    private static void sendChanges(Spreadsheet sheet, String spreadsheetId,int sheetId,int numCol,int numRows) throws GeneralSecurityException, IOException {
    	List<Request> requests = new ArrayList<>();
    	Color color=null;
    	if(numCol!=0) {
    		color=sheet.getSheets().get(0).getData().get(0).getRowData().get(numCol).getValues().get(0).getEffectiveFormat().getTextFormat().getForegroundColor();
    	}
    	else {
    		color=new Color().setRed(1f).setAlpha(null).setBlue(null).setGreen(null);
    	}
//    	Request request2=buildRequestToUpdateColor(sheet,numRows-1,numRows-1,0,0,sheetId,0/*numSheet*/,0/*numRow*/,numCol,0 /*numCell*/);
    	Request request1=setCellsStyle(sheetId,numRows,numRows+1,0,1,color);
    	requests.add(request1);
        BatchUpdateSpreadsheetRequest requestBody = new BatchUpdateSpreadsheetRequest();
        requestBody.setRequests(requests);
        Sheets sheetService=getService();
        BatchUpdateSpreadsheetRequest batchUpdateRequest = new BatchUpdateSpreadsheetRequest()
                .setRequests(requests);
        sheetService.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequest)
                .execute();
    }
    
    private static Request setCellsStyle(int sheetId, int startRowIndex, int endRowIndex, int startColumnIndex, int endColumnIndex, Color color)
    {
      return new Request().setRepeatCell(new RepeatCellRequest()
          .setCell(new CellData().setUserEnteredFormat(new CellFormat().setTextFormat(
                  new TextFormat().setForegroundColor(color))))
          .setRange(new GridRange().
        		  setSheetId(sheetId)
        		  .setStartRowIndex(startRowIndex)
        		  .setEndRowIndex(endRowIndex)
        		  .setStartColumnIndex(startColumnIndex)
        		  .setEndColumnIndex(endColumnIndex))
          .setFields("userEnteredFormat.textFormat"));
      
    }
}
