package DriveExcelMod;

import java.io.BufferedWriter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVFormat;

public class CSV {
	
	public static String create(List<String[]> aux,String fileName) throws IOException {
		String NAME_CSV_FILE = System.getProperty("user.home") + "/Downloads/"+fileName+".csv";
		try (
	            BufferedWriter writer = Files.newBufferedWriter(Paths.get(NAME_CSV_FILE));
				CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT
	                    .withHeader("firstname", "lastname", "username", "email").withDelimiter(';'));
	        ) {
			for(int i=0;i<aux.size();i++) {
				csvPrinter.printRecord(Arrays.asList(aux.get(i)));
			}
	        csvPrinter.flush();            
	        }
		return Paths.get(NAME_CSV_FILE).toString();
	}
}
